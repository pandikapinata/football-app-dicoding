package com.example.pandu.finalproject.model

data class LeagueResponse(
    val leagues: List<League>?
)