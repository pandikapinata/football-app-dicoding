package com.example.pandu.finalproject.model

data class League(
    val idLeague: String? = null,
    val strLeague: String? = null
//    val strLeagueAlternate: String? = null,
//    val strSport: String? = null
//    error cause get non-soccer sport, change to static string array
)