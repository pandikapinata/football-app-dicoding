package com.example.pandu.finalproject.model

class TeamResponse(
    val teams: List<Team>?
) {
}