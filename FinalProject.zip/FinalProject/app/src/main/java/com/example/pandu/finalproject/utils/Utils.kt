package com.example.pandu.finalproject.utils

import android.view.View
import java.text.SimpleDateFormat
import java.util.*

fun View.visible() {
    visibility = View.VISIBLE
}

fun View.invisible() {
    visibility = View.INVISIBLE
}

fun View.gone() {
    visibility = View.GONE
}

fun countList(input: String?): String {
    val zero = 0
    when (input) {
        null -> return zero.toString()
    }
    var result: List<String>? = input?.split(";")

    return (result?.count()?.minus(1)).toString()
}

fun stringReplace(input: String?): String? {
    val asal = ";"
    val tujuan = "\n"

    val hasil = input?.replace(asal, tujuan)
    return hasil
}

fun toDatetoString(dateStr: String, timeStr: String, mode: String) : String {
    val formatAsal = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
    val locale = Locale("in", "ID")
    val formatTujuan = SimpleDateFormat(mode, locale)
    formatTujuan.timeZone = TimeZone.getTimeZone("UTC")
    val dateTime = "$dateStr $timeStr"
    val date = formatAsal.parse(dateTime)
    return formatTujuan.format(date)
}