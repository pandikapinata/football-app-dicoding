package com.example.pandu.finalproject.model

data class PlayerResponse(
    val player: List<Player>?
)