package com.example.pandu.finalproject.model

data class MatchResponse(
    val events: List<Match>?
)